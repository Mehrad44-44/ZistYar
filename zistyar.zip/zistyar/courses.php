<?php include 'header.php'; ?>
<main class="flex-grow max-w-7xl mx-auto px-4 py-8 ">
  <h2 class="text-3xl font-bold text-green-700 mb-6 text-center">لیست دوره‌ها</h2>

  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
    <div class="bg-white border border-green-200 rounded-xl shadow-md p-6 hover:shadow-lg transition hover-3d">
      <h3 class="text-xl font-bold text-green-700 mb-2">دوره آموزش HTML & CSS</h3>
      <p class="text-gray-600 mb-4">مناسب مبتدی‌ها با پروژه واقعی و تمرین.</p>
      <div class="flex justify-between items-center">
        <span class="text-green-600 font-semibold">۴۹۰٬۰۰۰ تومان</span>
        <a href="cart.php?course=html-css" class="bg-green-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-green-700 transition">افزودن به سبد خرید</a>
      </div>
    </div>

    <div class="bg-white border border-green-200 rounded-xl shadow-md p-6 hover:shadow-lg transition hover-3d">
      <h3 class="text-xl font-bold text-green-700 mb-2">دوره جاوااسکریپت</h3>
      <p class="text-gray-600 mb-4">مفاهیم پایه تا پیشرفته + DOM و پروژه نهایی.</p>
      <div class="flex justify-between items-center">
        <span class="text-green-600 font-semibold">۶۵۰٬۰۰۰ تومان</span>
        <a href="#" class="bg-green-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-green-700 transition">افزودن به سبد خرید</a>
      </div>
    </div>
  </div>
</main>
<?php include 'footer.php'; ?>
