<?php include 'header.php'; ?>

<main class="flex-grow max-w-md mx-auto mt-16 bg-white shadow-md rounded-md p-8 mb-10">
  <h2 class="text-2xl font-bold text-center text-green-700 mb-6">بازیابی رمز عبور</h2>

  <form action="forgot-password-process.php" method="POST" class="space-y-4">
    <div>
      <label for="email" class="block text-sm font-medium mb-1">ایمیل خود را وارد کنید</label>
      <input type="email" id="email" name="email" required
        class="w-full px-4 py-2 border border-gray-300 rounded-md" placeholder="example@mail.com" />
    </div>

    <button type="submit" class="w-full bg-green-600 text-white py-2 rounded-md hover:bg-green-700 transition">
      ارسال لینک بازیابی
    </button>
  </form>

  <div class="mt-4 text-center text-sm">
    <a href="login.php" class="text-green-600 hover:underline">بازگشت به صفحه ورود</a>
  </div>
</main>

<?php include 'footer.php'; ?>
