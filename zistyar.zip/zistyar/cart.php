<?php
session_start();

// لیست دوره‌ها
$courses = [
  "html-css" => ["title" => "دوره HTML & CSS", "price" => 490000],
  "js" => ["title" => "دوره جاوااسکریپت", "price" => 650000]
];

// گرفتن آی‌دی دوره از URL
if (isset($_GET['course']) && isset($courses[$_GET['course']])) {
  $id = $_GET['course'];
  $_SESSION['cart'][] = $courses[$id];
  
}

// نمایش سبد خرید
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>سبد خرید</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">

  <h1 class="text-2xl font-bold text-green-700 mb-4">سبد خرید شما</h1>

  <?php if (!empty($_SESSION['cart'])): ?>
    <ul class="space-y-4">
      <?php foreach ($_SESSION['cart'] as $item): ?>
        <li class="bg-white shadow p-4 rounded border border-green-200">
          <div class="flex justify-between items-center">
            <span class="text-green-800 font-bold"><?= $item['title'] ?></span>
            <span class="text-gray-600"><?= number_format($item['price']) ?> تومان</span>
          </div>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php else: ?>
    <p class="text-gray-600">سبد خرید شما خالی است.</p>
  <?php endif; ?>

</body>
</html>
